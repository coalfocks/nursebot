import { generateText } from "ai"
import type { LabResult, VitalSigns } from "./types"

export async function generateLabResults(patientId: string, caseDescription: string): Promise<LabResult[]> {
  try {
    const { text } = await generateText({
      model: "openai/gpt-4o-mini",
      prompt: `Generate realistic lab results for a patient based on this case description: ${caseDescription}

Return a JSON array of lab results with the following structure:
{
  "testName": "string",
  "value": number,
  "unit": "string", 
  "referenceRange": "string",
  "status": "Normal" | "Abnormal" | "Critical"
}

Include common labs like CBC, BMP, liver function tests, and any specific tests relevant to the case. Make values realistic and medically appropriate. Some should be normal, some abnormal based on the case.`,
      temperature: 0.7,
    })

    const labData = JSON.parse(text)
    return labData.map((lab: any, index: number) => ({
      id: `generated-${Date.now()}-${index}`,
      patientId,
      testName: lab.testName,
      value: lab.value,
      unit: lab.unit,
      referenceRange: lab.referenceRange,
      status: lab.status,
      collectionTime: new Date().toISOString(),
      resultTime: new Date(Date.now() + 3600000).toISOString(), // 1 hour later
      orderedBy: "Dr. AI Generated",
    }))
  } catch (error) {
    console.error("Error generating lab results:", error)
    return []
  }
}

export async function generateVitalSigns(patientId: string, caseDescription: string): Promise<VitalSigns[]> {
  try {
    const { text } = await generateText({
      model: "openai/gpt-4o-mini",
      prompt: `Generate realistic vital signs for a patient over the last 24 hours based on this case: ${caseDescription}

Return a JSON array of 6-8 vital sign measurements with this structure:
{
  "temperature": number (96-104),
  "bloodPressureSystolic": number (80-180),
  "bloodPressureDiastolic": number (50-120),
  "heartRate": number (50-150),
  "respiratoryRate": number (12-30),
  "oxygenSaturation": number (85-100),
  "pain": number (0-10)
}

Make the values realistic for the patient's condition and show some variation over time.`,
      temperature: 0.7,
    })

    const vitalData = JSON.parse(text)
    return vitalData.map((vital: any, index: number) => ({
      id: `generated-${Date.now()}-${index}`,
      patientId,
      timestamp: new Date(Date.now() - index * 4 * 3600000).toISOString(), // Every 4 hours going back
      ...vital,
    }))
  } catch (error) {
    console.error("Error generating vital signs:", error)
    return []
  }
}
