import { generateText } from "ai"

export interface NoteGenerationRequest {
  patientId: string
  noteType: "H&P" | "Progress" | "Discharge" | "Consult" | "Nursing" | "Daily"
  caseDescription: string
  patientInfo: {
    name: string
    age: number
    gender: string
    chiefComplaint?: string
    allergies?: string[]
    medications?: string[]
  }
}

export async function generateClinicalNote(request: NoteGenerationRequest): Promise<string> {
  const { noteType, caseDescription, patientInfo } = request

  const prompts = {
    "H&P": `Generate a comprehensive History and Physical (H&P) note for a ${patientInfo.age}-year-old ${patientInfo.gender} patient. 

Case Description: ${caseDescription}

Patient: ${patientInfo.name}
Chief Complaint: ${patientInfo.chiefComplaint || "As described in case"}
Allergies: ${patientInfo.allergies?.join(", ") || "NKDA"}

Please format as a standard H&P with the following sections:
- Chief Complaint
- History of Present Illness
- Past Medical History
- Medications
- Allergies
- Social History
- Family History
- Review of Systems
- Physical Examination
- Assessment and Plan

Make it realistic and medically accurate.`,

    Progress: `Generate a daily progress note for a ${patientInfo.age}-year-old ${patientInfo.gender} patient.

Case Description: ${caseDescription}
Patient: ${patientInfo.name}

Format as a standard progress note with:
- Subjective
- Objective (including vital signs and physical exam)
- Assessment
- Plan

Keep it concise but thorough, focusing on the patient's current status and any changes from previous day.`,

    Daily: `Generate a daily note for a ${patientInfo.age}-year-old ${patientInfo.gender} patient.

Case Description: ${caseDescription}
Patient: ${patientInfo.name}

Include:
- Patient's current condition
- Overnight events
- Current medications and treatments
- Plan for the day
- Any concerns or changes needed

Keep it brief but informative for the medical team.`,

    Nursing: `Generate a nursing documentation note for a ${patientInfo.age}-year-old ${patientInfo.gender} patient.

Case Description: ${caseDescription}
Patient: ${patientInfo.name}

Include nursing-specific observations:
- Patient's general condition and comfort level
- Pain assessment and management
- Mobility and activity level
- Intake and output
- Skin integrity
- Patient education provided
- Family interactions
- Any nursing interventions performed

Focus on nursing care aspects and patient response to treatments.`,

    Consult: `Generate a consultation note for a ${patientInfo.age}-year-old ${patientInfo.gender} patient.

Case Description: ${caseDescription}
Patient: ${patientInfo.name}

Format as a specialist consultation with:
- Reason for consultation
- History (brief, focused on consultation reason)
- Physical examination (focused)
- Diagnostic impression
- Recommendations

Assume this is a specialist reviewing the case and providing expert recommendations.`,

    Discharge: `Generate a discharge summary for a ${patientInfo.age}-year-old ${patientInfo.gender} patient.

Case Description: ${caseDescription}
Patient: ${patientInfo.name}

Include:
- Admission diagnosis
- Hospital course summary
- Discharge diagnosis
- Discharge medications
- Follow-up instructions
- Activity restrictions
- When to seek medical attention

Focus on continuity of care and clear instructions for post-discharge management.`,
  }

  try {
    const { text } = await generateText({
      model: "openai/gpt-4o-mini",
      prompt: prompts[noteType],
      temperature: 0.7,
    })

    return text
  } catch (error) {
    console.error("Error generating clinical note:", error)
    return `Error generating ${noteType} note. Please try again.`
  }
}

export function formatNoteForDisplay(content: string, noteType: string, author: string, timestamp: string): string {
  const header = `
${noteType.toUpperCase()} NOTE
Date/Time: ${new Date(timestamp).toLocaleString()}
Author: ${author}
${"=".repeat(50)}

`
  return header + content
}
