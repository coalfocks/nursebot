"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Loader2, FileText, Sparkles } from "lucide-react"
import { generateClinicalNote, formatNoteForDisplay } from "@/lib/ai-notes"
import type { Patient, ClinicalNote } from "@/lib/types"

interface AINotesGeneratorProps {
  patient: Patient
  onNoteGenerated: (note: ClinicalNote) => void
}

export function AINotesGenerator({ patient, onNoteGenerated }: AINotesGeneratorProps) {
  const [isGenerating, setIsGenerating] = useState(false)
  const [noteType, setNoteType] = useState<"H&P" | "Progress" | "Discharge" | "Consult" | "Nursing" | "Daily">(
    "Progress",
  )
  const [caseDescription, setCaseDescription] = useState("")
  const [chiefComplaint, setChiefComplaint] = useState("")
  const [generatedNote, setGeneratedNote] = useState("")

  const handleGenerateNote = async () => {
    if (!caseDescription.trim()) return

    setIsGenerating(true)
    try {
      const noteContent = await generateClinicalNote({
        patientId: patient.id,
        noteType,
        caseDescription,
        patientInfo: {
          name: `${patient.firstName} ${patient.lastName}`,
          age: new Date().getFullYear() - new Date(patient.dateOfBirth).getFullYear(),
          gender: patient.gender,
          chiefComplaint,
          allergies: patient.allergies,
        },
      })

      const formattedNote = formatNoteForDisplay(
        noteContent,
        noteType,
        patient.attendingPhysician,
        new Date().toISOString(),
      )

      setGeneratedNote(formattedNote)

      // Create note object
      const newNote: ClinicalNote = {
        id: Date.now().toString(),
        patientId: patient.id,
        type: noteType,
        title: `${noteType} Note - ${new Date().toLocaleDateString()}`,
        content: formattedNote,
        author: patient.attendingPhysician,
        timestamp: new Date().toISOString(),
        signed: false,
      }

      onNoteGenerated(newNote)
    } catch (error) {
      console.error("Error generating note:", error)
    } finally {
      setIsGenerating(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5" />
            AI Clinical Note Generator
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="noteType">Note Type</Label>
              <Select value={noteType} onValueChange={(value: any) => setNoteType(value)}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="H&P">History & Physical</SelectItem>
                  <SelectItem value="Progress">Progress Note</SelectItem>
                  <SelectItem value="Daily">Daily Note</SelectItem>
                  <SelectItem value="Nursing">Nursing Documentation</SelectItem>
                  <SelectItem value="Consult">Consultation Note</SelectItem>
                  <SelectItem value="Discharge">Discharge Summary</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="chiefComplaint">Chief Complaint (Optional)</Label>
              <Input
                id="chiefComplaint"
                placeholder="e.g., Chest pain, Shortness of breath"
                value={chiefComplaint}
                onChange={(e) => setChiefComplaint(e.target.value)}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="caseDescription">Case Description</Label>
            <Textarea
              id="caseDescription"
              placeholder="Describe the patient's case, symptoms, history, and current condition. Be as detailed as possible for better note generation..."
              value={caseDescription}
              onChange={(e) => setCaseDescription(e.target.value)}
              rows={6}
              className="resize-none"
            />
          </div>

          <div className="flex items-center gap-2">
            <Button
              onClick={handleGenerateNote}
              disabled={isGenerating || !caseDescription.trim()}
              className="flex items-center gap-2"
            >
              {isGenerating ? (
                <>
                  <Loader2 className="h-4 w-4 animate-spin" />
                  Generating...
                </>
              ) : (
                <>
                  <FileText className="h-4 w-4" />
                  Generate {noteType} Note
                </>
              )}
            </Button>
            <Badge variant="outline">AI-Powered</Badge>
          </div>
        </CardContent>
      </Card>

      {generatedNote && (
        <Card>
          <CardHeader>
            <CardTitle>Generated Note Preview</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="bg-muted p-4 rounded-lg">
              <pre className="whitespace-pre-wrap text-sm font-mono">{generatedNote}</pre>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
