"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ScrollArea } from "@/components/ui/scroll-area"
import { FileText, Plus, Calendar, User, CheckCircle, Clock } from "lucide-react"
import { AINotesGenerator } from "./ai-note-generator"
import type { Patient, ClinicalNote } from "@/lib/types"

interface ClinicalNotesProps {
  patient: Patient
}

export function ClinicalNotes({ patient }: ClinicalNotesProps) {
  const [notes, setNotes] = useState<ClinicalNote[]>([
    {
      id: "1",
      patientId: patient.id,
      type: "H&P",
      title: "History & Physical - Admission",
      content: `HISTORY & PHYSICAL
Date/Time: ${new Date().toLocaleDateString()} 08:30
Author: ${patient.attendingPhysician}
${"=".repeat(50)}

CHIEF COMPLAINT: "My stomach hurts."

HISTORY OF PRESENT ILLNESS: 
37 y.o. male presents with a gnawing dull ache in his stomach for the last several days after eating at the local taco stand. He relates no recent illness, but he has been taking Excedrin for his migraines. Patient has longstanding GERD, but he says this feels different. There has been no weight loss, but he has noticed some intermittent black stool. His bowel habits are otherwise the same.

PAST MEDICAL HISTORY: 
- GERD
- Migraines

MEDICATIONS: 
- Excedrin for migraines
- Protonix 40mg PO q24 hrs

ALLERGIES: NKDA

SOCIAL HISTORY: 
Denies tobacco, alcohol, or illicit drug use.

FAMILY HISTORY: 
Non-contributory

REVIEW OF SYSTEMS: 
GEN: some loss in weight, no fever or chills, no night sweats
HEENT: +HA, no change in vision, no stuffy nose or sore throat
NECK: no pain or trouble swallowing
HEART: no chest pain or SOB, no leg edema, no claudication
LUNG: no cough, no pain w/ deep breathing
GI: no prior n/v/d, + heartburn, + gnawing epigastric pain
GU: no blood in urine, no dysuria, no nocturia
ENDO: no polydipsia, no polyuria, denies heat or cold intolerance
MS: no joint pain or stiffness, L knee arthritis
NEURO: no fainting or local weakness, no vertigo/dizzy
PSYCH: no depression or anxiety, denies SI/SA, mild insomnia

PHYSICAL EXAMINATION:
Vital Signs: T 98.6°F, BP 128/82, HR 78, RR 16, O2 Sat 98% RA
General: Alert, oriented, no acute distress
HEENT: PERRL, EOMI, no scleral icterus
Neck: Supple, no lymphadenopathy
Cardiovascular: RRR, no murmurs
Pulmonary: Clear to auscultation bilaterally
Abdomen: Soft, mild epigastric tenderness, no rebound or guarding
Extremities: No edema, pulses intact
Neurologic: Alert and oriented x3, no focal deficits

ASSESSMENT AND PLAN:
1. Epigastric pain - likely peptic ulcer disease vs gastritis
   - NPO for now
   - PPI therapy
   - H. pylori testing
   - Consider EGD if symptoms persist

2. GERD - continue current management
   - Continue Protonix

3. Migraines - stable
   - Continue current regimen`,
      author: patient.attendingPhysician,
      timestamp: new Date(Date.now() - 86400000).toISOString(), // Yesterday
      signed: true,
    },
  ])

  const [showGenerator, setShowGenerator] = useState(false)

  const handleNoteGenerated = (newNote: ClinicalNote) => {
    setNotes([newNote, ...notes])
    setShowGenerator(false)
  }

  const notesByType = notes.reduce(
    (acc, note) => {
      if (!acc[note.type]) acc[note.type] = []
      acc[note.type].push(note)
      return acc
    },
    {} as Record<string, ClinicalNote[]>,
  )

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Clinical Notes</h2>
        <Button onClick={() => setShowGenerator(!showGenerator)} className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          Generate AI Note
        </Button>
      </div>

      {showGenerator && <AINotesGenerator patient={patient} onNoteGenerated={handleNoteGenerated} />}

      <Tabs defaultValue="all" className="w-full">
        <TabsList>
          <TabsTrigger value="all">All Notes ({notes.length})</TabsTrigger>
          <TabsTrigger value="H&P">H&P ({notesByType["H&P"]?.length || 0})</TabsTrigger>
          <TabsTrigger value="Progress">Progress ({notesByType["Progress"]?.length || 0})</TabsTrigger>
          <TabsTrigger value="Daily">Daily ({notesByType["Daily"]?.length || 0})</TabsTrigger>
          <TabsTrigger value="Nursing">Nursing ({notesByType["Nursing"]?.length || 0})</TabsTrigger>
          <TabsTrigger value="Consult">Consult ({notesByType["Consult"]?.length || 0})</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="mt-6">
          <div className="space-y-4">
            {notes.map((note) => (
              <Card key={note.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <FileText className="h-5 w-5" />
                      <div>
                        <CardTitle className="text-lg">{note.title}</CardTitle>
                        <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                          <div className="flex items-center gap-1">
                            <User className="h-3 w-3" />
                            {note.author}
                          </div>
                          <div className="flex items-center gap-1">
                            <Calendar className="h-3 w-3" />
                            {new Date(note.timestamp).toLocaleString()}
                          </div>
                        </div>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={note.type === "H&P" ? "default" : "secondary"}>{note.type}</Badge>
                      {note.signed ? (
                        <Badge variant="default" className="flex items-center gap-1">
                          <CheckCircle className="h-3 w-3" />
                          Signed
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          Pending
                        </Badge>
                      )}
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <ScrollArea className="h-64 w-full">
                    <pre className="whitespace-pre-wrap text-sm font-mono bg-muted p-4 rounded-lg">{note.content}</pre>
                  </ScrollArea>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {Object.entries(notesByType).map(([type, typeNotes]) => (
          <TabsContent key={type} value={type} className="mt-6">
            <div className="space-y-4">
              {typeNotes.map((note) => (
                <Card key={note.id}>
                  <CardHeader>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <FileText className="h-5 w-5" />
                        <div>
                          <CardTitle className="text-lg">{note.title}</CardTitle>
                          <div className="flex items-center gap-4 mt-1 text-sm text-muted-foreground">
                            <div className="flex items-center gap-1">
                              <User className="h-3 w-3" />
                              {note.author}
                            </div>
                            <div className="flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              {new Date(note.timestamp).toLocaleString()}
                            </div>
                          </div>
                        </div>
                      </div>
                      {note.signed ? (
                        <Badge variant="default" className="flex items-center gap-1">
                          <CheckCircle className="h-3 w-3" />
                          Signed
                        </Badge>
                      ) : (
                        <Badge variant="outline" className="flex items-center gap-1">
                          <Clock className="h-3 w-3" />
                          Pending
                        </Badge>
                      )}
                    </div>
                  </CardHeader>
                  <CardContent>
                    <ScrollArea className="h-64 w-full">
                      <pre className="whitespace-pre-wrap text-sm font-mono bg-muted p-4 rounded-lg">
                        {note.content}
                      </pre>
                    </ScrollArea>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>
        ))}
      </Tabs>
    </div>
  )
}
